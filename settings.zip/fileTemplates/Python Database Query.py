# Created by ${USER} on ${DATE}
from uprr_telecom_common_utils.Print.print_verbose import print_verbose
from uprr_telecom_tools.Databases.Prod461 import Prod461
from pandas import DataFrame
from pathlib import Path


def ${NAME}(prod461: Prod461, verbose: bool = False) -> DataFrame:
    """Description about what Function Does"""
    
    if verbose:
        print_verbose(f"Getting Data from Prod461")
    
    sql_file_name: str = ""
    sql_file_path: Path = Path(f'')
    sql_query: str = open(sql_file_path, mode="r").read()
    
    prod461.sql_query = sql_query
    prod461.run_query()
    
    if verbose:
        print_verbose(f"Rows Retrieved: {len(prod461.data):,}")
    
    return prod461.data
