# Created by ${USER} on ${DATE}
from uprr_telecom_common_utils.Print.print_verbose import print_verbose
from uprr_telecom_common_utils.Utils.get_runtime import get_runtime
from uprr_telecom_email_tools.Templates import failure_email
from uprr_telecom_email_tools.TimedEmails import nightly_sanity_check_email
from Resources import Resources
from App import App
import datetime
import os


def ${NAME}() -> None:
    """Description about what Application Does"""
    
    return None
    
if __name__ == "__main__":
    print_verbose(f"\nStarting Continuous Running Application: {App.application_name}")
    
    script_start = datetime.datetime.now()
    
    while True:
        App.run += 1
        print_verbose(f'\nRun #: {App.run:,} Starting')
        App.start_time = datetime.datetime.now()
        
        try:
            ${NAME}()
        except Exception as exception:
            print_verbose(f"{App.application_name} Failed to Run")
            print_verbose(f"Exception: {exception}")
            
            failure_email.failure_email(
                script_name=App.application_name, exception=str(exception), send_to="ajdittmar@up.com"
            )
        
        runtime = get_runtime(start_time=script_start)
        nightly_sanity_check_email.nightly_sanity_check_email(App=App, runtime=runtime)
        
        print_verbose(f"\nRun #: [{App.run:,}] Complete")
        print_verbose(f"RunTime: {get_runtime(App.start_time)}")
       
        
