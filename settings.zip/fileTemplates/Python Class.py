# Created by ${USER} on ${DATE}
from uprr_telecom_common_utils.Print.print_verbose import print_verbose

class ${NAME}:

    def __init__(self, verbose: bool = False) -> None:
        if verbose:
            print_verbose("Initializing Object: ${NAME}")
            
        self.verbose: bool = verbose
        
        return

if __name__ == "__main__":
    test_obj: ${NAME} = ${NAME}()
