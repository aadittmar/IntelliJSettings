@Test
public void ${NAME}() throws Exception {
    
}