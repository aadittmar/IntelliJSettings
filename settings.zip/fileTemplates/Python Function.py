# Created by ${USER} on ${DATE}
from uprr_telecom_common_utils.Print.print_verbose import print_verbose


def ${NAME}() -> None:
    """Description about what Function Does"""
    
    return None
    
    
if __name__ == "__main__":
    ${NAME}()
